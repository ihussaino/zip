import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/ihussaino/listz/master/cartoon.txt'
addon = xbmcaddon.Addon('plugin.video.arabicdisney')